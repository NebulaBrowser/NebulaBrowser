#!/bin/bash

# перейти в папку, где лежит этот скрипт
cd "$(dirname "$0")"

# ЯВНО вызываем python3 из /usr/local/bin
/usr/local/bin/python3 NebulaBrowser.py