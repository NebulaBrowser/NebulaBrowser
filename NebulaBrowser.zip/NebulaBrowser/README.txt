Nebula Browser — lightweight Python web browser

How to run:
- Windows: double-click NebulaBrowser.bat
- macOS / Linux: open terminal, run ./NebulaBrowser.sh

Requirements:
- Python 3.9+
- PyQt5
- PyQtWebEngine