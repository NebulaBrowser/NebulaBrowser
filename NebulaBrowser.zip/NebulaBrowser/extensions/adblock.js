
document.querySelectorAll("iframe").forEach(e => {
    if (e.src.includes("ads") || e.src.includes("doubleclick") || e.src.includes("googlesyndication"))
        e.remove();
});
const removeVideoAds = () => {
    let ads = document.querySelectorAll(".ytp-ad-module, .video-ads, .ad-showing");
    ads.forEach(a => a.remove());
};
setInterval(removeVideoAds, 300);
