
let css = `
html, body { background-color: #111 !important; color: #eee !important; }
img, video { filter: brightness(0.85); }
`;
let s = document.createElement("style"); s.innerText = css; document.head.appendChild(s);
