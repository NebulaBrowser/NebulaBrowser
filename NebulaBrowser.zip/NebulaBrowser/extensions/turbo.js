
let css = `* { animation: none !important; transition: none !important; }`;
let s = document.createElement("style"); s.innerText = css; document.head.appendChild(s);
window.addEventListener = function(){};
document.addEventListener = function(){};
